// Copyright (c) 2025, Tirthan Shah and contributors
// For license information, please see license.txt

// frappe.ui.form.on("Cutting Plan Final", {
// 	refresh(frm) {

// 	},
// });
