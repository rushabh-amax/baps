# Copyright (c) 2025, Ayush Patel and contributors
# For license information, please see license.txt

# import frappe
from frappe.tests.utils import FrappeTestCase


class TestSizeListGenerationDetails(FrappeTestCase):
	pass
