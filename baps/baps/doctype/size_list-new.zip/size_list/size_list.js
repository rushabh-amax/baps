// ============================
// Size List - Role-based Verification System
// ============================

// Add CSS for verification status styling
if (!document.querySelector('#verification-status-styles')) {
    const style = document.createElement('style');
    style.id = 'verification-status-styles';
    style.textContent = `
        /* Verified row styling */
        .grid-row.verification-verified {
            background-color: #d4edda !important;
            border-left: 5px solid #28a745 !important;
        }
        
        /* Partially verified row styling */
        .grid-row.verification-partial {
            background-color: #fff3cd !important;
            border-left: 5px solid #ffc107 !important;
        }
        
        /* Verified field styling */
        .verification-verified input,
        .verification-verified select,
        .verification-verified textarea {
            background-color: #d4edda !important;
            border: 1px solid #28a745 !important;
        }
        
        /* Verification checkbox styling */
        .verification-checkbox {
            accent-color: #28a745;
        }
        
        .verification-checkbox:checked {
            background-color: #28a745;
        }
        
        /* Hide verification fields for Data Operators */
        .hide-for-operator {
            display: none !important;
        }
    `;
    document.head.appendChild(style);
}

frappe.ui.form.on('Size List', {
    refresh: function(frm) {
        setup_role_based_permissions(frm);
        setup_verification_events(frm);
        update_verification_progress(frm);
        update_workflow_status(frm);
        highlight_fields_needing_attention(frm);
        add_verification_buttons(frm);
        update_row_styling(frm);
        
        // Setup child table permissions
        setup_child_table_permissions(frm);
        setup_child_row_field_permissions(frm);
    },
    
    onload: function(frm) {
        setup_role_based_permissions(frm);
        setup_child_table_permissions(frm);
        setup_child_row_field_permissions(frm);
    },
    
    validate: function(frm) {
        // ============================================================================
        // CRITICAL: PREVENT ANY MODIFICATIONS TO VERIFIED/PUBLISHED DOCUMENTS
        // ============================================================================
        const current_status = frm.doc.workflow_status || 'Draft';
        const is_admin = frappe.user_roles.includes('Administrator') || frappe.user_roles.includes('System Manager');
        
        if ((current_status === 'Verified' || current_status === 'Published') && !is_admin) {
            frappe.validated = false;
            frappe.msgprint({
                title: __('Document Locked'),
                message: __('🔒 This document is {0} and cannot be modified. Only System Managers can edit verified documents.', [current_status]),
                indicator: 'red'
            });
            return false;
        }
    },
    
    // Main field verification events
    form_number_verified: function(frm) {
        handle_main_field_verification(frm, 'form_number', frm.doc.form_number_verified);
    },
    
    baps_project_verified: function(frm) {
        handle_main_field_verification(frm, 'baps_project', frm.doc.baps_project_verified);
    },
    
    prep_date_verified: function(frm) {
        handle_main_field_verification(frm, 'prep_date', frm.doc.prep_date_verified);
    },
    
    stone_type_verified: function(frm) {
        handle_main_field_verification(frm, 'stone_type', frm.doc.stone_type_verified);
    },
    
    main_part_verified: function(frm) {
        handle_main_field_verification(frm, 'main_part', frm.doc.main_part_verified);
    },
    
    sub_part_verified: function(frm) {
        handle_main_field_verification(frm, 'sub_part', frm.doc.sub_part_verified);
    },
    
    cutting_region_verified: function(frm) {
        handle_main_field_verification(frm, 'cutting_region', frm.doc.cutting_region_verified);
    },
    
    overall_form_verified: function(frm) {
        // Individual verification only - no automatic bulk marking
        update_verification_progress(frm);
    },
    
    // Field change events - reset verification when data changes
    form_number: function(frm) {
        if (frappe.user_roles.includes('Size List Data Entry Operator')) {
            frm.set_value('form_number_verified', 0);
            update_verification_progress(frm);
        }
    },
    
    baps_project: function(frm) {
        if (frappe.user_roles.includes('Size List Data Entry Operator')) {
            frm.set_value('baps_project_verified', 0);
            update_verification_progress(frm);
        }
    },
    
    prep_date: function(frm) {
        if (frappe.user_roles.includes('Size List Data Entry Operator')) {
            frm.set_value('prep_date_verified', 0);
            update_verification_progress(frm);
        }
    },
    
    stone_type: function(frm) {
        if (frappe.user_roles.includes('Size List Data Entry Operator')) {
            frm.set_value('stone_type_verified', 0);
            update_verification_progress(frm);
        }
    },
    
    main_part: function(frm) {
        if (frappe.user_roles.includes('Size List Data Entry Operator')) {
            frm.set_value('main_part_verified', 0);
            update_verification_progress(frm);
        }
    },
    
    sub_part: function(frm) {
        if (frappe.user_roles.includes('Size List Data Entry Operator')) {
            frm.set_value('sub_part_verified', 0);
            update_verification_progress(frm);
        }
    },
    
    cutting_region: function(frm) {
        if (frappe.user_roles.includes('Size List Data Entry Operator')) {
            frm.set_value('cutting_region_verified', 0);
            update_verification_progress(frm);
        }
    }
});

// Child table events
frappe.ui.form.on('Size List Details', {
    form_render: function(frm, cdt, cdn) {
        setup_child_table_permissions(frm);
        setup_child_row_field_permissions(frm, cdt, cdn);
    },
    // Verification checkbox events
    stone_name_verified: function(frm, cdt, cdn) {
        handle_child_field_verification(frm, cdt, cdn, 'stone_name');
    },
    
    stone_code_verified: function(frm, cdt, cdn) {
        handle_child_field_verification(frm, cdt, cdn, 'stone_code');
    },
    
    l1_verified: function(frm, cdt, cdn) {
        handle_child_field_verification(frm, cdt, cdn, 'l1');
    },
    
    l2_verified: function(frm, cdt, cdn) {
        handle_child_field_verification(frm, cdt, cdn, 'l2');
    },
    
    b1_verified: function(frm, cdt, cdn) {
        handle_child_field_verification(frm, cdt, cdn, 'b1');
    },
    
    b2_verified: function(frm, cdt, cdn) {
        handle_child_field_verification(frm, cdt, cdn, 'b2');
    },
    
    h1_verified: function(frm, cdt, cdn) {
        handle_child_field_verification(frm, cdt, cdn, 'h1');
    },
    
    h2_verified: function(frm, cdt, cdn) {
        handle_child_field_verification(frm, cdt, cdn, 'h2');
    },
    
    row_verified: function(frm, cdt, cdn) {
        handle_row_verification(frm, cdt, cdn);
    },
    
    // Data field change events - reset verification
    stone_name: function(frm, cdt, cdn) {
        if (frappe.user_roles.includes('Size List Data Entry Operator')) {
            frappe.model.set_value(cdt, cdn, 'stone_name_verified', 0);
            update_child_row_verification(frm, cdt, cdn);
        }
        calculate_volume(frm, cdt, cdn);
    },
    
    stone_code: function(frm, cdt, cdn) {
        if (frappe.user_roles.includes('Size List Data Entry Operator')) {
            frappe.model.set_value(cdt, cdn, 'stone_code_verified', 0);
            update_child_row_verification(frm, cdt, cdn);
        }
    },
    
    l1: function(frm, cdt, cdn) {
        if (frappe.user_roles.includes('Size List Data Entry Operator')) {
            frappe.model.set_value(cdt, cdn, 'l1_verified', 0);
            update_child_row_verification(frm, cdt, cdn);
        }
        calculate_volume(frm, cdt, cdn);
    },
    
    l2: function(frm, cdt, cdn) {
        if (frappe.user_roles.includes('Size List Data Entry Operator')) {
            frappe.model.set_value(cdt, cdn, 'l2_verified', 0);
            update_child_row_verification(frm, cdt, cdn);
        }
        calculate_volume(frm, cdt, cdn);
    },
    
    b1: function(frm, cdt, cdn) {
        if (frappe.user_roles.includes('Size List Data Entry Operator')) {
            frappe.model.set_value(cdt, cdn, 'b1_verified', 0);
            update_child_row_verification(frm, cdt, cdn);
        }
        calculate_volume(frm, cdt, cdn);
    },
    
    b2: function(frm, cdt, cdn) {
        if (frappe.user_roles.includes('Size List Data Entry Operator')) {
            frappe.model.set_value(cdt, cdn, 'b2_verified', 0);
            update_child_row_verification(frm, cdt, cdn);
        }
        calculate_volume(frm, cdt, cdn);
    },
    
    h1: function(frm, cdt, cdn) {
        if (frappe.user_roles.includes('Size List Data Entry Operator')) {
            frappe.model.set_value(cdt, cdn, 'h1_verified', 0);
            update_child_row_verification(frm, cdt, cdn);
        }
        calculate_volume(frm, cdt, cdn);
    },
    
    h2: function(frm, cdt, cdn) {
        if (frappe.user_roles.includes('Size List Data Entry Operator')) {
            frappe.model.set_value(cdt, cdn, 'h2_verified', 0);
            update_child_row_verification(frm, cdt, cdn);
        }
        calculate_volume(frm, cdt, cdn);
    },




// ====== RANGE handler (expanded and robust) ======
   range: function(frm, cdt, cdn) {
    let row = locals[cdt][cdn];
    if (!row || !row.range) return;

    let input = row.range.toString().trim();
    if (!input) return;

    // Parse input into list of numbers
    let numbers = [];
    let parts = input.split(',').map(s => s.trim()).filter(s => s);

    parts.forEach(part => {
        if (part.includes('-')) {
            let rangeParts = part.split('-').map(s => s.trim());
            if (rangeParts.length === 2) {
                let start = parseInt(rangeParts[0], 10);
                let end = parseInt(rangeParts[1], 10);
                if (isNaN(start) || isNaN(end) || start > end) {
                    frappe.show_alert({ message: "Invalid range → " + part, indicator: "red" });
                    return;
                }
                for (let i = start; i <= end; i++) numbers.push(i);
            }
        } else {
            let n = parseInt(part, 10);
            if (!isNaN(n)) numbers.push(n);
        }
    });

    numbers = [...new Set(numbers)].sort((a, b) => a - b);

    if (numbers.length === 0) {
        frappe.show_alert({ message: "⚠️ No valid numbers found in range", indicator: "orange" });
        return;
    }

    // First number stays in current row, rest create new rows
    frappe.model.set_value(cdt, cdn, "stone_name", row.stone_name || numbers[0].toString());

    for (let i = 1; i < numbers.length; i++) {
        let new_row = frappe.model.add_child(frm.doc, "Size List Details", "stone_details");
        frappe.model.set_value(new_row.doctype, new_row.name, "stone_name", numbers[i].toString());
    }

    frm.refresh_field("stone_details");
    frappe.show_alert({
        message: `✅ ${numbers.length} rows generated from range`,
        indicator: "green"
    });
}
});



// ============================================================================
// STONE DETAILS CHILD TABLE - PREVENT ROW ADDITIONS IN VERIFIED DOCUMENTS
// ============================================================================
frappe.ui.form.on('Stone Details', {
    before_stone_details_insert: function(frm, cdt, cdn) {
        const current_status = frm.doc.workflow_status || 'Draft';
        const is_admin = frappe.user_roles.includes('Administrator') || frappe.user_roles.includes('System Manager');
        
        if ((current_status === 'Verified' || current_status === 'Published') && !is_admin) {
            frappe.validated = false;
            frappe.msgprint({
                title: __('Row Addition Blocked'),
                message: __('🔒 Cannot add new rows to verified documents. Document status: {0}', [current_status]),
                indicator: 'red'
            });
            return false;
        }
    },
    
    stone_details_remove: function(frm, cdt, cdn) {
        const current_status = frm.doc.workflow_status || 'Draft';
        const is_admin = frappe.user_roles.includes('Administrator') || frappe.user_roles.includes('System Manager');
        
        if ((current_status === 'Verified' || current_status === 'Published') && !is_admin) {
            frappe.validated = false;
            frappe.msgprint({
                title: __('Row Deletion Blocked'),
                message: __('🔒 Cannot delete rows from verified documents. Document status: {0}', [current_status]),
                indicator: 'red'
            });
            // Prevent deletion by refreshing the field
            setTimeout(function() {
                frm.refresh_field('stone_details');
            }, 100);
            return false;
        }
    }
});

// Role-based permissions setup
function setup_role_based_permissions(frm) {
    console.log('=== PERMISSION SETUP ===');
    console.log('Current user:', frappe.session.user);
    console.log('User roles:', frappe.user_roles);
    
    // Priority-based role checking - most restrictive role takes precedence
    const has_data_operator = frappe.user_roles.includes('Size List Data Entry Operator');
    const has_data_checker = frappe.user_roles.includes('Size List Data Checker');
    const has_project_manager = frappe.user_roles.includes('Size List Project Manager');
    const has_admin = frappe.user_roles.includes('Administrator') || frappe.user_roles.includes('System Manager');
    
    // Determine primary role (highest priority wins)
    let primary_role = 'none';
    if (has_admin) {
        primary_role = 'admin';
    } else if (has_project_manager) {
        primary_role = 'project_manager';
    } else if (has_data_checker) {
        primary_role = 'data_checker';
    } else if (has_data_operator) {
        primary_role = 'data_operator';
    }
    
    console.log('User role flags:', {
        has_data_operator, has_data_checker, has_project_manager, has_admin
    });
    console.log('Primary role determined:', primary_role);
    
    // ============================================================================
    // CRITICAL: VERIFIED DOCUMENTS ARE COMPLETELY READ-ONLY FOR ALL USERS
    // (except System Manager and Administrator)
    // ============================================================================
    const current_status = frm.doc.workflow_status || 'Draft';
    console.log('Document status:', current_status);
    
    if ((current_status === 'Verified' || current_status === 'Published') && !has_admin) {
        console.log('🔒 DOCUMENT LOCKED: Making form read-only for verified/published document');
        frm.set_read_only();
        
        // Add clear messaging
        frm.dashboard.add_comment(__('🔒 <strong>DOCUMENT LOCKED</strong>: This document is {0} and is completely READ-ONLY. Only System Managers can modify verified documents.', [current_status]), 'red', true);
        
        // Set workflow status field description
        frm.set_df_property('workflow_status', 'description', '🔒 Document is locked - No modifications allowed');
        frm.refresh_field('workflow_status');
        
        // Show lock icon in the title
        if (frm.doc.__islocal !== 1) {
            $('.form-title-area .title-text').append(' 🔒');
        }
        
        return; // Exit early - no further permission processing needed
    }
    
    const verification_fields = [
        'form_number_verified', 'baps_project_verified', 'prep_date_verified',
        'stone_type_verified', 'main_part_verified', 'sub_part_verified',
        'cutting_region_verified', 'polishing_verified', 'overall_form_verified'
    ];
    
    const data_fields = [
        'form_number', 'baps_project', 'prep_date', 'stone_type', 
        'main_part', 'sub_part', 'cutting_region', 'polishing', 
        'chemical', 'dry_fitting', 'carving', 'project_name'
    ];
    
    if (primary_role === 'data_operator') {
        const operator_current_status = frm.doc.workflow_status || 'Draft';
        console.log('✓ Data Entry Operator (Primary Role) - Current Status:', operator_current_status);
        
        // Show verification fields ONLY when status is "Under Recheck"
        if (operator_current_status === 'Under Recheck') {
            console.log('✓ Data Entry Operator: Showing verification fields (Under Recheck status)');
            show_verification_fields(frm);
            
            // Make verification fields read-only for Data Entry Operator
            verification_fields.forEach(field => {
                frm.set_df_property(field, 'read_only', 1);
                frm.refresh_field(field);
            });
        } else {
            console.log('✓ Data Entry Operator: Hiding verification fields (Not Under Recheck)');
            hide_verification_fields(frm);
        }
        
        // ============================================================================
        // FIELD-LEVEL PERMISSIONS: Only non-verified fields can be edited by Data Entry Operator
        // This is critical for "Under Recheck" status where operator fixes only unchecked fields
        // ============================================================================
        
        const field_verification_map = {
            'form_number': 'form_number_verified',
            'baps_project': 'baps_project_verified', 
            'prep_date': 'prep_date_verified',
            'stone_type': 'stone_type_verified',
            'main_part': 'main_part_verified',
            'sub_part': 'sub_part_verified',
            'cutting_region': 'cutting_region_verified',
            'polishing': 'polishing_verified'
        };
        
        console.log('🎯 Setting field-level permissions based on verification status...');
        
        data_fields.forEach(field => {
            const verification_field = field_verification_map[field];
            const is_verified = verification_field ? frm.doc[verification_field] : false;
            
            if (operator_current_status === 'Under Recheck') {
                if (is_verified) {
                    // Field is verified by Data Entry Checker - CANNOT edit (read-only)
                    frm.set_df_property(field, 'read_only', 1);
                    frm.set_df_property(field, 'description', '✅ Verified by Checker - Read Only');
                    console.log(`🔒 Field ${field} is verified - read-only for operator in Under Recheck`);
                } else {
                    // Field is NOT verified - Data Entry Operator CAN edit (needs correction)
                    frm.set_df_property(field, 'read_only', 0);
                    frm.set_df_property(field, 'description', '⚠️ Not verified - Please correct this field');
                    console.log(`✏️ Field ${field} is NOT verified - editable for operator in Under Recheck`);
                }
            } else if (operator_current_status === 'Draft') {
                // Draft status - all fields editable
                frm.set_df_property(field, 'read_only', 0);
                frm.set_df_property(field, 'description', '');
            } else {
                // Other statuses (Under Verification, Verified) - all fields read-only for operators
                frm.set_df_property(field, 'read_only', 1);
                frm.set_df_property(field, 'description', `📋 Status: ${operator_current_status} - Read Only`);
            }
            
            frm.refresh_field(field);
        });
        
        // Data Entry Operator workflow status control
        const current_status = frm.doc.workflow_status || 'Draft';
        
        // CRITICAL: Data Entry Operators CANNOT edit Verified or Published documents
        if (current_status === 'Verified' || current_status === 'Published') {
            frappe.msgprint(__('🔒 This document is {0} and cannot be edited by Data Entry Operators. Only Data Checkers and Project Managers can modify verified documents.', [current_status]), 'Edit Restriction');
            
            // Make entire form read-only for verified documents
            frm.set_read_only();
            frm.set_df_property('workflow_status', 'description', '🔒 Document locked - Cannot edit Verified/Published documents');
            return;
        }
        
        // Allow status changes only for Draft documents
        if (current_status === 'Draft') {
            frm.set_df_property('workflow_status', 'read_only', 0);
            frm.set_df_property('workflow_status', 'options', 'Draft\nUnder Verification');
            frm.set_df_property('workflow_status', 'description', '💡 You can change to "Under Verification" to submit for checking');
        } else if (current_status === 'Under Recheck') {
            frm.set_df_property('workflow_status', 'read_only', 0);
            frm.set_df_property('workflow_status', 'options', 'Under Recheck\nUnder Verification');
            frm.set_df_property('workflow_status', 'description', '🔄 Make corrections and resubmit for verification');
        } else {
            frm.set_df_property('workflow_status', 'read_only', 1);
            frm.set_df_property('workflow_status', 'description', '📋 Status controlled by workflow');
        }
        frm.refresh_field('workflow_status');
        
    } else if (primary_role === 'data_checker') {
        const current_status = frm.doc.workflow_status || 'Draft';
        console.log('✓ Data Checker (Primary Role) - Current Status:', current_status);
        
        // Data Checkers should NOT see Draft documents
        if (current_status === 'Draft') {
            // frappe.throw(__('Data Entry Checkers cannot access Draft documents. Only "Under Verification" and "Verified" documents are accessible.'));
            return;
        }
        
        // Show verification fields for Data Checker
        show_verification_fields(frm);
        
        // Make verification fields editable
        verification_fields.forEach(field => {
            frm.set_df_property(field, 'read_only', 0);
            frm.refresh_field(field);
        });
        
        // Make data fields read-only for Data Checker
        data_fields.forEach(field => {
            frm.set_df_property(field, 'read_only', 1);
            frm.refresh_field(field);
        });
        
        // Data Checker can manually change status for Under Verification documents
        if (current_status === 'Under Verification') {
            frm.set_df_property('workflow_status', 'read_only', 0);
            frm.set_df_property('workflow_status', 'description', '✅ You can change status to "Verified" or "Under Recheck"');
            console.log('✓ Data Checker can change status from Under Verification');
        } else {
            frm.set_df_property('workflow_status', 'read_only', 1);
            frm.set_df_property('workflow_status', 'description', '📊 Status managed by verification progress');
        }
        frm.refresh_field('workflow_status');
        
    } else if (primary_role === 'project_manager') {
        console.log('✓ Project Manager (Primary Role): Access to Verified and Published documents');
        // Project Manager logic here if needed
        show_verification_fields(frm);
        
    } else if (primary_role === 'admin') {
        console.log('✓ Admin: Full access to all fields');
        // Show verification fields
        show_verification_fields(frm);
        
        // Make all fields editable for Admin
        verification_fields.forEach(field => {
            frm.set_df_property(field, 'read_only', 0);
            frm.refresh_field(field);
        });
        
        data_fields.forEach(field => {
            frm.set_df_property(field, 'read_only', 0);
            frm.refresh_field(field);
        });
        
        // Admin can change status manually
        frm.set_df_property('workflow_status', 'read_only', 0);
        frm.set_df_property('workflow_status', 'description', '🔧 Admin: Full status control');
        frm.refresh_field('workflow_status');
        
    } else if (is_project_manager && !is_admin) {
        console.log('✓ Project Manager: View verified documents, can publish');
        // Hide verification fields for Project Manager (they don't need to see checkboxes)
        hide_verification_fields(frm);
        
        // Make all data fields read-only for Project Manager
        data_fields.forEach(field => {
            frm.set_df_property(field, 'read_only', 1);
            frm.refresh_field(field);
        });
        
        // Project Manager can change Verified to Published
        const current_status = frm.doc.workflow_status || 'Draft';
        if (current_status === 'Verified') {
            frm.set_df_property('workflow_status', 'read_only', 0);
            frm.set_df_property('workflow_status', 'options', 'Verified\nPublished');
            frm.set_df_property('workflow_status', 'description', '📢 You can change to "Published" to publish this verified document');
        } else {
            frm.set_df_property('workflow_status', 'read_only', 1);
            frm.set_df_property('workflow_status', 'description', '');
        }
        frm.refresh_field('workflow_status');
    }
    
    console.log('=== END PERMISSION SETUP ===');
}

function make_data_fields_readonly(frm) {
    const data_fields = [
        'form_number', 'baps_project', 'prep_date', 'stone_type', 
        'main_part', 'sub_part', 'cutting_region', 'polishing', 
        'chemical', 'dry_fitting', 'carving'
    ];
    
    data_fields.forEach(field => {
        frm.set_df_property(field, 'read_only', 1);
    });
}

function make_data_fields_editable(frm) {
    const data_fields = [
        'form_number', 'baps_project', 'prep_date', 'stone_type', 
        'main_part', 'sub_part', 'cutting_region', 'polishing', 
        'chemical', 'dry_fitting', 'carving'
    ];
    
    data_fields.forEach(field => {
        frm.set_df_property(field, 'read_only', 0);
    });
}

function make_verification_fields_editable(frm) {
    console.log('Making verification fields editable...');
    const verification_fields = [
        'form_number_verified', 'baps_project_verified', 'prep_date_verified',
        'stone_type_verified', 'main_part_verified', 'sub_part_verified',
        'cutting_region_verified', 'overall_form_verified'
    ];
    
    verification_fields.forEach(field => {
        console.log('Making field editable:', field);
        frm.set_df_property(field, 'read_only', 0);
        frm.set_df_property(field, 'hidden', 0);
        frm.refresh_field(field);
    });
}

function show_verification_fields(frm) {
    const verification_fields = [
         'baps_project_verified', 
        'stone_type_verified', 'main_part_verified', 'sub_part_verified',
        'cutting_region_verified', 'overall_form_verified', 'verification_progress'
    ];
    
    verification_fields.forEach(field => {
        frm.set_df_property(field, 'hidden', 0);
    });
}

function hide_verification_fields(frm) {
    const verification_fields = [
        'form_number_verified', 'baps_project_verified', 
        'stone_type_verified', 'main_part_verified', 'sub_part_verified',
        'cutting_region_verified', 'overall_form_verified', 'verification_progress'
    ];
    
    verification_fields.forEach(field => {
        frm.set_df_property(field, 'hidden', 1);
    });
}

// Verification event handlers
function handle_main_field_verification(frm, field, is_verified) {
    if (is_verified) {
        frappe.show_alert({
            message: `✅ ${field} verified`,
            indicator: 'green'
        });
    } else {
        frappe.show_alert({
            message: `❌ ${field} verification removed`,
            indicator: 'orange'
        });
    }
    
    update_verification_progress(frm);
    update_workflow_status(frm);
    
    // Refresh field permissions when verification status changes
    setTimeout(() => {
        setup_role_based_permissions(frm);
    }, 100);
}

function handle_child_field_verification(frm, cdt, cdn, field) {
    const row = locals[cdt][cdn];
    const is_verified = row[field + '_verified'];
    
    if (is_verified) {
        frappe.show_alert({
            message: `✅ ${field} verified for ${row.stone_name || 'Row ' + row.idx}`,
            indicator: 'green'
        });
    } else {
        frappe.show_alert({
            message: `❌ ${field} verification removed for ${row.stone_name || 'Row ' + row.idx}`,
            indicator: 'orange'
        });
    }
    
    update_child_row_verification(frm, cdt, cdn);
    update_verification_progress(frm);
    update_workflow_status(frm);
    
    // Update field permissions for all rows when verification changes
    frm.doc.stone_details.forEach(row => {
        setup_child_row_field_permissions(frm, row.doctype, row.name);
    });
}

function handle_row_verification(frm, cdt, cdn) {
    const row = locals[cdt][cdn];
    
    if (row.row_verified) {
        frappe.show_alert({
            message: `✅ Row marked as verified for ${row.stone_name || 'Row ' + row.idx}`,
            indicator: 'green'
        });
    } else {
        frappe.show_alert({
            message: `❌ Row verification removed for ${row.stone_name || 'Row ' + row.idx}`,
            indicator: 'orange'
        });
    }
    
    update_verification_progress(frm);
}

// Progress calculation
function update_verification_progress(frm) {
    const main_verification_fields = [
        'baps_project_verified', 'stone_type_verified', 'main_part_verified', 
        'sub_part_verified', 'cutting_region_verified'
    ];
    
    let verified_main_fields = 0;
    main_verification_fields.forEach(field => {
        if (frm.doc[field]) verified_main_fields++;
    });
    
    const main_progress = (verified_main_fields / main_verification_fields.length) * 100;
    
    // Calculate child table progress
    let total_child_fields = 0;
    let verified_child_fields = 0;
    
    frm.doc.stone_details.forEach(row => {
        const child_verification_fields = [
            'stone_name_verified', 'stone_code_verified', 'l1_verified',
            'l2_verified', 'b1_verified', 'b2_verified', 'h1_verified', 'h2_verified'
        ];
        
        child_verification_fields.forEach(field => {
            total_child_fields++;
            if (row[field]) verified_child_fields++;
        });
    });
    
    const child_progress = total_child_fields > 0 ? (verified_child_fields / total_child_fields) * 100 : 100;
    
    // Overall progress
    const overall_progress = (main_progress + child_progress) / 2;
    
    frm.set_value('verification_progress', Math.round(overall_progress));
    
    // No automatic overall form verification - Data Entry Checker must manually check this
}

function update_child_row_verification(frm, cdt, cdn) {
    // Individual verification only - no automatic row verification
    // Each field must be manually verified by the Data Entry Checker
    update_row_styling(frm);
}

// Visual styling updates
function update_row_styling(frm) {
    setTimeout(() => {
        frm.doc.stone_details.forEach((row, index) => {
            const verification_fields = [
                'stone_name_verified', 'stone_code_verified', 'l1_verified',
                'l2_verified', 'b1_verified', 'b2_verified', 'h1_verified', 'h2_verified'
            ];
            
            let verified_count = 0;
            verification_fields.forEach(field => {
                if (row[field]) verified_count++;
            });
            
            const grid_row = frm.fields_dict.stone_details.grid.grid_rows[index];
            if (grid_row && grid_row.wrapper) {
                grid_row.wrapper.classList.remove('verification-verified', 'verification-partial');
                
                if (verified_count === verification_fields.length) {
                    grid_row.wrapper.classList.add('verification-verified');
                } else if (verified_count > 0) {
                    grid_row.wrapper.classList.add('verification-partial');
                }
            }
        });
    }, 100);
}

// Utility functions
function add_verification_buttons(frm) {
    // No bulk verification buttons - individual field verification only
    // Data Entry Checker will verify each field individually by ticking checkboxes
}

// Individual field verification only - no bulk operations
// Data Entry Checker will verify each field individually by ticking checkboxes

function calculate_volume(frm, cdt, cdn) {
    let row = locals[cdt][cdn];
    if (row) {
        let l = (row.l1 || 0) + (row.l2 || 0) / 12;
        let b = (row.b1 || 0) + (row.b2 || 0) / 12;
        let h = (row.h1 || 0) + (row.h2 || 0) / 12;
        
        row.volume = Math.round(l * b * h * 1000) / 1000;
        frm.refresh_field('stone_details');
    }
}

function setup_verification_events(frm) {
    // This function can be used for any additional verification setup
    // Currently handled by individual field events
}

function setup_child_table_permissions(frm) {
    console.log('=== CHILD TABLE PERMISSION SETUP ===');
    
    const is_data_operator = frappe.user_roles.includes('Size List Data Entry Operator');
    const is_data_checker = frappe.user_roles.includes('Size List Data Checker');
    const is_admin = frappe.user_roles.includes('Administrator') || frappe.user_roles.includes('System Manager');
    
    // ============================================================================
    // CRITICAL: PREVENT ADDING NEW ROWS IN VERIFIED/PUBLISHED DOCUMENTS
    // ============================================================================
    const current_status = frm.doc.workflow_status || 'Draft';
    console.log('Document status for child table:', current_status);
    
    if ((current_status === 'Verified' || current_status === 'Published') && !is_admin) {
        console.log('🔒 CHILD TABLE LOCKED: Preventing new row additions for verified/published document');
        
        if (frm.fields_dict.stone_details && frm.fields_dict.stone_details.grid) {
            // Disable adding new rows
            frm.fields_dict.stone_details.grid.cannot_add_rows = true;
            frm.fields_dict.stone_details.grid.cannot_delete_rows = true;
            frm.fields_dict.stone_details.grid.static_rows = true;
            
            // Hide add/delete buttons
            frm.fields_dict.stone_details.grid.grid_buttons.find('.grid-add-row').hide();
            frm.fields_dict.stone_details.grid.wrapper.find('.grid-add-row').hide();
            frm.fields_dict.stone_details.grid.wrapper.find('.btn-open-row').hide();
            
            // Make all child table fields read-only
            frm.fields_dict.stone_details.grid.docfields.forEach(df => {
                df.read_only = 1;
            });
            
            frm.fields_dict.stone_details.grid.refresh();
            frm.refresh_field('stone_details');
            
            console.log('✓ Child table completely locked for verified document');
            return; // Exit early - no further processing needed
        }
    }
    
    const verification_fields = [
        'stone_name_verified', 'stone_code_verified', 'l1_verified',
        'l2_verified', 'b1_verified', 'b2_verified', 'h1_verified', 
        'h2_verified', 'row_verified'
    ];
    
    const data_fields = [
        'stone_name', 'stone_code', 'range', 'l1', 'l2', 'b1', 'b2', 'h1', 'h2'
    ];
    
    if (frm.fields_dict.stone_details && frm.fields_dict.stone_details.grid) {
        
        if (is_data_operator && !is_data_checker && !is_admin) {
            console.log('✓ Data Entry Operator: Show child verification fields as read-only, make data fields editable');
            
            // Show verification fields as read-only for Data Entry Operator
            verification_fields.forEach(field => {
                frm.fields_dict.stone_details.grid.docfields.forEach(df => {
                    if (df.fieldname === field) {
                        df.hidden = 0;
                        df.read_only = 1; // Read-only so operator can see but not change
                        console.log('✓ Child verification field shown as read-only:', field);
                    }
                });
            });
            
            // Make data fields editable ONLY if not verified for Data Entry Operator
            // Note: Child table field editability will be set row by row in the form_render event
            data_fields.forEach(field => {
                frm.fields_dict.stone_details.grid.docfields.forEach(df => {
                    if (df.fieldname === field) {
                        // Default to editable - will be overridden per row based on verification status
                        df.read_only = 0;
                    }
                });
            });
            
        } else if (is_data_checker && !is_admin) {
            console.log('✓ Data Checker: Show child verification fields, make data fields read-only');
            
            // Show and enable verification fields for Data Checker
            verification_fields.forEach(field => {
                frm.fields_dict.stone_details.grid.docfields.forEach(df => {
                    if (df.fieldname === field) {
                        console.log('✓ Child verification field enabled:', field);
                        df.hidden = 0;
                        df.read_only = 0;
                    }
                });
            });
            
            // Make data fields read-only for Data Checker
            data_fields.forEach(field => {
                frm.fields_dict.stone_details.grid.docfields.forEach(df => {
                    if (df.fieldname === field) {
                        df.read_only = 1;
                        console.log('✓ Child data field made read-only:', field);
                    }
                });
            });
            
        } else if (is_admin) {
            console.log('✓ Admin: Full access to child fields');
            
            // Show verification fields and make all fields editable for Admin
            verification_fields.forEach(field => {
                frm.fields_dict.stone_details.grid.docfields.forEach(df => {
                    if (df.fieldname === field) {
                        df.hidden = 0;
                        df.read_only = 0;
                    }
                });
            });
            
            data_fields.forEach(field => {
                frm.fields_dict.stone_details.grid.docfields.forEach(df => {
                    if (df.fieldname === field) {
                        df.read_only = 0;
                    }
                });
            });
        }
        
        console.log('✓ Child table grid refreshing...');
        frm.fields_dict.stone_details.grid.refresh();
    }
    
    frm.refresh_field('stone_details');
    console.log('=== END CHILD TABLE SETUP ===');
}

// ============================================================================
// CHILD TABLE ROW-LEVEL FIELD PERMISSIONS FOR "UNDER RECHECK" STATUS
// ============================================================================
function setup_child_row_field_permissions(frm) {
    const current_status = frm.doc.workflow_status || 'Draft';
    const is_data_operator = frappe.user_roles.includes('Size List Data Entry Operator');
    const is_admin = frappe.user_roles.includes('Administrator') || frappe.user_roles.includes('System Manager');
    
    if (current_status === 'Under Recheck' && is_data_operator && !is_admin) {
        console.log('🎯 Setting child table field permissions for Under Recheck status...');
        
        // Field mapping for child table
        const child_field_verification_map = {
            'stone_name': 'stone_name_verified',
            'stone_code': 'stone_code_verified',
            'l1': 'l1_verified',
            'l2': 'l2_verified',
            'b1': 'b1_verified',
            'b2': 'b2_verified',
            'h1': 'h1_verified',
            'h2': 'h2_verified'
        };
        
        // Process each row in the child table
        if (frm.doc.stone_details) {
            frm.doc.stone_details.forEach((row, index) => {
                Object.keys(child_field_verification_map).forEach(field_name => {
                    const verification_field = child_field_verification_map[field_name];
                    const is_verified = row[verification_field] || false;
                    
                    // Find the grid row
                    const grid_row = frm.fields_dict.stone_details.grid.grid_rows[index];
                    if (grid_row && grid_row.doc) {
                        const field_obj = grid_row.grid_form.fields_dict[field_name];
                        if (field_obj) {
                            if (is_verified) {
                                // Field is verified - make read-only
                                field_obj.df.read_only = 1;
                                field_obj.df.description = '✅ Verified - Read Only';
                                console.log(`🔒 Row ${index + 1} Field ${field_name} verified - read-only`);
                            } else {
                                // Field is not verified - allow editing
                                field_obj.df.read_only = 0;
                                field_obj.df.description = '⚠️ Not verified - Please correct';
                                console.log(`✏️ Row ${index + 1} Field ${field_name} not verified - editable`);
                            }
                            field_obj.refresh();
                        }
                    }
                });
            });
        }
    }
}

// Add event handler for stone_details form render to apply row-level permissions
frappe.ui.form.on('Stone Details', {
    form_render: function(frm, cdt, cdn) {
        // Apply field-level permissions when each row is rendered
        setup_child_row_field_permissions(frm);
    }
});

// Workflow Status Management
function update_workflow_status(frm) {
    console.log('=== UPDATING WORKFLOW STATUS ===');
    
    // Main form verification fields
    const main_verification_fields = [
        'form_number_verified', 'baps_project_verified', 'prep_date_verified',
        'stone_type_verified', 'main_part_verified', 'sub_part_verified',
        'cutting_region_verified', 'polishing_verified'
    ];
    
    // Count verified main fields
    let main_verified_count = 0;
    main_verification_fields.forEach(field => {
        if (frm.doc[field] === 1) {
            main_verified_count++;
        }
    });
    
    // Count verified child table rows
    let child_verified_count = 0;
    let total_child_rows = 0;
    
    if (frm.doc.stone_details && frm.doc.stone_details.length > 0) {
        total_child_rows = frm.doc.stone_details.length;
        
        frm.doc.stone_details.forEach(row => {
            const child_verification_fields = [
                'stone_name_verified', 'stone_code_verified', 'l1_verified',
                'l2_verified', 'b1_verified', 'b2_verified', 'h1_verified', 
                'h2_verified'
            ];
            
            let row_verified_count = 0;
            child_verification_fields.forEach(field => {
                if (row[field] === 1) {
                    row_verified_count++;
                }
            });
            
            // If all fields in this row are verified, count it
            if (row_verified_count === child_verification_fields.length) {
                child_verified_count++;
            }
        });
    }
    
    const total_main_fields = main_verification_fields.length;
    const main_all_verified = main_verified_count === total_main_fields;
    const child_all_verified = (total_child_rows === 0) || (child_verified_count === total_child_rows);
    
    console.log('Main verified:', main_verified_count, '/', total_main_fields);
    console.log('Child verified:', child_verified_count, '/', total_child_rows);
    console.log('Main all verified:', main_all_verified);
    console.log('Child all verified:', child_all_verified);
    
    let new_status;
    
    // Determine status based on verification progress
    if (main_all_verified && child_all_verified) {
        new_status = 'Verified';
        console.log('✓ Status: VERIFIED - All fields verified');
    } else if (main_verified_count > 0 || child_verified_count > 0) {
        // Some fields are verified, but not all
        if (main_verified_count > 0 && main_verified_count < total_main_fields) {
            new_status = 'Under Recheck';
            console.log('✓ Status: UNDER RECHECK - Partial main verification');
        } else if (child_verified_count > 0 && child_verified_count < total_child_rows) {
            new_status = 'Under Recheck';
            console.log('✓ Status: UNDER RECHECK - Partial child verification');
        } else {
            new_status = 'Under Verification';
            console.log('✓ Status: UNDER VERIFICATION - In progress');
        }
    } else {
        new_status = 'Draft';
        console.log('✓ Status: DRAFT - No verification started');
    }
    
    // Update status if it has changed
    if (frm.doc.workflow_status !== new_status) {
        console.log('Updating status from', frm.doc.workflow_status, 'to', new_status);
        frm.set_value('workflow_status', new_status);
    }
    
    console.log('=== END WORKFLOW STATUS UPDATE ===');
}

// Highlight fields that need operator attention
function highlight_fields_needing_attention(frm) {
    const is_data_operator = frappe.user_roles.includes('Size List Data Entry Operator');
    const is_under_recheck = frm.doc.workflow_status === 'Under Recheck';
    
    if (!is_data_operator || !is_under_recheck) return;
    
    console.log('=== HIGHLIGHTING FIELDS NEEDING ATTENTION ===');
    
    // Main form verification fields to check
    const main_verification_fields = [
        // { field: 'form_number', verification: 'form_number_verified', label: 'Form Number' },
        { field: 'baps_project', verification: 'baps_project_verified', label: 'BAPS Project' },
        // { field: 'prep_date', verification: 'prep_date_verified', label: 'Prep Date' },
        { field: 'stone_type', verification: 'stone_type_verified', label: 'Stone Type' },
        { field: 'main_part', verification: 'main_part_verified', label: 'Main Part' },
        { field: 'sub_part', verification: 'sub_part_verified', label: 'Sub Part' },
        { field: 'cutting_region', verification: 'cutting_region_verified', label: 'Cutting Region' },
        { field: 'polishing', verification: 'polishing_verified', label: 'Polishing' }
    ];
    
    let unverified_fields = [];
    
    // Check which main fields are not verified
    main_verification_fields.forEach(item => {
        if (!frm.doc[item.verification]) {
            unverified_fields.push(item.label);
            // Add visual indicator to unverified fields
            // frm.set_df_property(item.field, 'description', '⚠️ This field needs your attention - not yet verified');
        } else {
            // Remove description for verified fields
            frm.set_df_property(item.field, 'description', '✅ Verified');
        }
        frm.refresh_field(item.field);
    });
    
    // Show alert if there are unverified fields
    if (unverified_fields.length > 0) {
        frappe.show_alert({
            message: `⚠️ Please review these fields: ${unverified_fields.join(', ')}`,
            indicator: 'orange'
        }, 8);
    }
    
    console.log('Unverified fields:', unverified_fields);
    console.log('=== END HIGHLIGHTING ===');
}

// Setup field-level permissions for child table rows based on verification status
function setup_child_row_field_permissions(frm, cdt, cdn) {
    const is_data_operator = frappe.user_roles.includes('Size List Data Entry Operator');
    const is_data_checker = frappe.user_roles.includes('Size List Data Checker');
    const is_admin = frappe.user_roles.includes('Administrator') || frappe.user_roles.includes('System Manager');
    
    if (!is_data_operator || is_data_checker || is_admin) return;
    
    console.log('=== CHILD ROW FIELD PERMISSIONS ===');
    
    const row = locals[cdt][cdn];
    const row_wrapper = frm.fields_dict.stone_details.grid.grid_rows_by_docname[cdn];
    
    if (!row_wrapper) return;
    
    // Field verification mapping for child table
    const child_field_verification_map = {
        'stone_name': 'stone_name_verified',
        'stone_code': 'stone_code_verified',
        'l1': 'l1_verified',
        'l2': 'l2_verified',
        'b1': 'b1_verified',
        'b2': 'b2_verified',
        'h1': 'h1_verified',
        'h2': 'h2_verified'
    };
    
    // Apply permissions to each field based on verification status
    Object.keys(child_field_verification_map).forEach(field => {
        const verification_field = child_field_verification_map[field];
        const is_field_verified = row[verification_field] === 1;
        
        const field_wrapper = row_wrapper.get_field(field);
        if (field_wrapper) {
            if (is_field_verified) {
                // Field is verified - make read-only
                field_wrapper.set_value(row[field]);
                field_wrapper.$input.prop('readonly', true);
                field_wrapper.$input.css('background-color', '#e9ecef');
                field_wrapper.$input.attr('title', 'This field is verified and cannot be edited');
                console.log(`✓ Child field ${field} in row ${row.idx} is verified - read-only`);
            } else {
                // Field is not verified - editable
                field_wrapper.$input.prop('readonly', false);
                field_wrapper.$input.css('background-color', '');
                field_wrapper.$input.attr('title', 'You can edit this field as it is not yet verified');
                console.log(`✓ Child field ${field} in row ${row.idx} is not verified - editable`);
            }
        }
    });
    
    console.log('=== END CHILD ROW PERMISSIONS ===');
}




