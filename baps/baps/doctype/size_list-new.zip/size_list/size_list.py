import frappe
from frappe import _
from frappe.model.document import Document

class SizeList(Document):
    def has_permission(self, ptype="read", user=None):
        """Status-based document visibility and edit control"""
        if not user:
            user = frappe.session.user
        
        user_roles = frappe.get_roles(user)
        
        # System Manager and Administrator can do everything
        if "System Manager" in user_roles or "Administrator" in user_roles:
            return True
        
        current_status = self.workflow_status or "Draft"
        
        # STRICT ENFORCEMENT: Data Entry Checkers CANNOT access Draft documents
        if "Size List Data Checker" in user_roles and current_status == "Draft":
            frappe.throw(_("Access Denied: Data Entry Checkers cannot view Draft documents. Only 'Under Verification' and 'Verified' documents are accessible."))
            return False
        
        # ============================================================================
        # CRITICAL: VERIFIED DOCUMENTS ARE COMPLETELY READ-ONLY FOR ALL USERS
        # Only System Managers and Administrators can edit Verified/Published documents
        # ============================================================================
        if ptype in ["write", "submit", "cancel"] and current_status in ["Verified", "Published"]:
            frappe.throw(_("🔒 DOCUMENT LOCKED: Verified and Published documents are completely READ-ONLY. Only System Managers can modify these documents."))
            return False
        
        # STRICT Priority-based role checking - Data Checker restrictions override all others
        # This ensures users with multiple roles cannot bypass Data Checker restrictions
        
        # CRITICAL: If user has Data Checker role, they CANNOT see Draft documents (highest restriction)
        if "Size List Data Checker" in user_roles:
            allowed_statuses = ["Under Verification", "Verified"]
            if ptype in ["write", "submit", "cancel"]:
                # Data Checkers can only edit Under Verification documents
                return current_status == "Under Verification"
            return current_status in allowed_statuses
        
        # Project Manager can see: Verified, Published (but cannot edit them)
        elif "Size List Project Manager" in user_roles:
            if ptype in ["write", "submit", "cancel"]:
                # Project Managers can only edit their workflow (Verified -> Published transition)
                return current_status == "Verified"
            return current_status in ["Verified", "Published"]
        
        # Data Entry Operator permissions
        elif "Size List Data Entry Operator" in user_roles:
            if ptype in ["write", "submit", "cancel"]:
                # Operators can only edit Draft, Under Recheck documents (NOT Verified)
                return current_status in ["Draft", "Under Recheck"]
            else:
                # Operators can view Draft, Under Verification, Under Recheck, AND Verified (READ-ONLY)
                return current_status in ["Draft", "Under Verification", "Under Recheck", "Verified"]
        
        return False
    
    def validate(self):
        """Validate status transitions based on user role"""
        if self.has_value_changed("workflow_status"):
            user_roles = frappe.get_roles()
            old_status = self.get_doc_before_save().workflow_status if self.get_doc_before_save() else "Draft"
            new_status = self.workflow_status
            
            # Define allowed transitions for each role
            allowed_transitions = {
                "Size List Data Entry Operator": [
                    ("Draft", "Under Verification")
                ],
                "Size List Data Checker": [
                    ("Under Verification", "Verified"),
                    ("Under Verification", "Under Recheck")
                ],
                "Size List Project Manager": [
                    ("Verified", "Published")
                ]
            }
            
            # Check if the transition is allowed for the user's role
            valid_transition = False
            for role in user_roles:
                if role in allowed_transitions:
                    if (old_status, new_status) in allowed_transitions[role]:
                        valid_transition = True
                        break
                elif role in ["Administrator", "System Manager"]:
                    valid_transition = True
                    break
            
            if not valid_transition:
                frappe.throw(
                    _("You cannot change status from '{0}' to '{1}' with your current role").format(
                        old_status, new_status
                    )
                )
    
    def before_save(self):
        """Handle automatic status transitions and messages"""
        user_roles = frappe.get_roles()
        current_status = self.workflow_status or "Draft"
        
        # ============================================================================
        # ABSOLUTE ENFORCEMENT: VERIFIED DOCUMENTS ARE COMPLETELY READ-ONLY
        # ============================================================================
        
        # Check if document is being modified while in Verified or Published status
        if current_status in ["Verified", "Published"]:
            # Only System Manager and Administrator can modify Verified/Published documents
            if not ("System Manager" in user_roles or "Administrator" in user_roles):
                # Check for child table modifications
                self._check_child_table_changes()
                frappe.throw(_("🔒 DOCUMENT LOCKED: This document is {0} and is completely READ-ONLY. No modifications are allowed except by System Managers.").format(current_status))
        
        # CRITICAL ENFORCEMENT: Data Entry Checkers CANNOT access or modify Draft documents
        if "Size List Data Checker" in user_roles and current_status == "Draft":
            frappe.throw(_("STRICT ACCESS CONTROL: Data Entry Checkers are absolutely prohibited from accessing Draft documents. Only 'Under Verification' and 'Verified' documents are permitted."))
        
        # Show appropriate messages for status changes
        if self.has_value_changed("workflow_status"):
            old_status = self.get_doc_before_save().workflow_status if self.get_doc_before_save() else "Draft"
            
            if "Size List Data Entry Operator" in user_roles:
                if old_status == "Draft" and self.workflow_status == "Under Verification":
                    frappe.msgprint(_("Document submitted for verification"), alert=True)
            
            if "Size List Data Checker" in user_roles:
                if old_status == "Under Verification" and self.workflow_status == "Verified":
                    frappe.msgprint(_("Document verified successfully"), alert=True)
                elif old_status == "Under Verification" and self.workflow_status == "Under Recheck":
                    frappe.msgprint(_("Document sent back for corrections"), alert=True)
        
        # Project Manager can publish Verified documents by saving
        if ("Size List Project Manager" in user_roles or "Administrator" in user_roles):
            if current_status == "Verified" and self.has_value_changed("workflow_status") == False:
                # If Project Manager saves a Verified document without changing status, auto-publish
                self.workflow_status = "Published"
                frappe.msgprint(_("Document automatically published"), alert=True)

    def _check_child_table_changes(self):
        """Check for unauthorized child table modifications in verified documents"""
        # Get the document before save to compare
        if not self.get_doc_before_save():
            return
        
        old_doc = self.get_doc_before_save()
        current_status = self.workflow_status or "Draft"
        
        # For verified/published documents, check if child table rows were added/removed
        if current_status in ["Verified", "Published"]:
            old_stone_details = old_doc.get("stone_details") or []
            new_stone_details = self.get("stone_details") or []
            
            # Check if number of rows changed
            if len(old_stone_details) != len(new_stone_details):
                frappe.throw(_("🔒 CHILD TABLE LOCKED: Cannot add or remove rows in {0} documents. New rows: {1}, Old rows: {2}").format(
                    current_status, len(new_stone_details), len(old_stone_details)
                ))
            
            # Check if any rows were actually modified (by comparing idx values)
            old_idx_set = set([row.idx for row in old_stone_details if row.idx])
            new_idx_set = set([row.idx for row in new_stone_details if row.idx])
            
            if old_idx_set != new_idx_set:
                frappe.throw(_("🔒 CHILD TABLE LOCKED: Cannot modify row structure in {0} documents.").format(current_status))


@frappe.whitelist()
def get_permission_query_conditions(user=None):
    """Filter documents based on user role and status"""
    if not user:
        user = frappe.session.user
    
    user_roles = frappe.get_roles(user)
    
    # System Manager and Administrator can see everything
    if "System Manager" in user_roles or "Administrator" in user_roles:
        return ""
    
    # STRICT Priority-based role checking - Data Checker restrictions override all others
    # This ensures users with multiple roles cannot bypass Data Checker restrictions
    
    # CRITICAL: If user has Data Checker role, they CANNOT see Draft documents (highest restriction)
    if "Size List Data Checker" in user_roles:
        return "`tabSize List`.`workflow_status` in ('Under Verification', 'Verified')"
    
    # Project Manager can see: Verified, Published
    elif "Size List Project Manager" in user_roles:
        return "`tabSize List`.`workflow_status` in ('Verified', 'Published')"
    
    # Data Entry Operator can see: Draft, Under Verification, Under Recheck, Verified (read-only)
    elif "Size List Data Entry Operator" in user_roles:
        return "`tabSize List`.`workflow_status` in ('Draft', 'Under Verification', 'Under Recheck', 'Verified')"
    
    # If no matching role, return condition that shows nothing
    return "`tabSize List`.`name` = ''"


# def autoname(doc, method):
#     if frappe.db.exists("Size List Creation", {"form_number": doc.form_number}):
#         frappe.throw(_("Form No must be unique"))
#     doc.name = doc.form_number


# def validate(doc, method):
#     total = 0
#     new_stone_details = []

#     # 🔹 Fetch linked Baps Project (if any)
#     project_chemical = 0
#     project_dry_fitting = 0
#     if doc.baps_project:
#         project = frappe.get_doc("Baps Project", doc.baps_project)
#         project_chemical = 1 if project.chemical else 0
#         project_dry_fitting = 1 if project.dry_fitting else 0

#     for d in doc.stone_details:
#         # --- Validation: l2, b2, h2 must be less than 12 ---
#         if (d.l2 or 0) >= 12:
#             frappe.throw(_("L2 (inches) must be less than 12 in row {0}").format(d.idx))
#         if (d.b2 or 0) >= 12:
#             frappe.throw(_("B2 (inches) must be less than 12 in row {0}").format(d.idx))
#         if (d.h2 or 0) >= 12:
#             frappe.throw(_("H2 (inches) must be less than 12 in row {0}").format(d.idx))

#         # --- Apply project checkboxes to child rows ---
#         if project_chemical:
#             d.chemical = 1
#         # else: keep whatever user set

#         if project_dry_fitting:
#             d.dry_fitting = 1
#         # else: keep whatever user set

#         # --- Handle Range Expansion ---
#         if d.range:
#             numbers = []

#             if "-" in d.range:
#                 try:
#                     start, end = d.range.split("-")
#                     start, end = int(start), int(end)
#                 except Exception:
#                     frappe.throw(_("Invalid range format in row {0}. Use like 001-003").format(d.idx))

#                 if start > end:
#                     frappe.throw(_("Range start cannot be greater than end in row {0}").format(d.idx))

#                 numbers = [i for i in range(start, end + 1)]

#             elif "," in d.range:
#                 try:
#                     numbers = [int(x.strip()) for x in d.range.split(",") if x.strip()]
#                 except Exception:
#                     frappe.throw(_("Invalid list format in row {0}. Use like 001,002,005").format(d.idx))

#             else:
#                 frappe.throw(_("Invalid range/list format in row {0}. Use like 001-003 or 001,002,005").format(d.idx))

#             prefix = d.stone_code or (d.stone_name or "").upper()

#             for i in numbers:
#                 new_row = {
#                     "stone_name": d.stone_name,
#                     "stone_code": f"{prefix}{i:03d}",
#                     "l1": d.l1, "l2": d.l2,
#                     "b1": d.b1, "b2": d.b2,
#                     "h1": d.h1, "h2": d.h2,
#                     "chemical": d.chemical,
#                     "dry_fitting": d.dry_fitting
#                 }

#                 # Calculate volume
#                 l = (new_row["l1"] or 0) + (new_row["l2"] or 0) / 12
#                 b = (new_row["b1"] or 0) + (new_row["b2"] or 0) / 12
#                 h = (new_row["h1"] or 0) + (new_row["h2"] or 0) / 12
#                 new_row["volume"] = round(l * b * h, 3)

#                 total += new_row["volume"]
#                 new_stone_details.append(new_row)

#         else:
#             # --- Normal row ---
#             l = (d.l1 or 0) + (d.l2 or 0) / 12
#             b = (d.b1 or 0) + (d.b2 or 0) / 12
#             h = (d.h1 or 0) + (d.h2 or 0) / 12
#             d.volume = round(l * b * h, 3)
#             total += d.volume
#             new_stone_details.append(d.as_dict())

#     # --- Replace child table with expanded rows ---
#     doc.stone_details = []
#     for row in new_stone_details:
#         doc.append("stone_details", row)

#     doc.total_volume = round(total, 3)

import frappe
from frappe import _
from frappe.model.document import Document

class SizeList(Document):
    pass


def autoname(doc, method):
    if frappe.db.exists("Size List Creation", {"form_number": doc.form_number}):
        frappe.throw(_("Form No must be unique"))
    doc.name = doc.form_number


def validate(doc, method):
    total = 0
    new_stone_details = []

    # 🔹 Fetch linked Baps Project (if any)
    project_chemical = 0
    project_dry_fitting = 0
    if doc.baps_project:
        project = frappe.get_doc("Baps Project", doc.baps_project)
        project_chemical = 1 if project.chemical else 0
        project_dry_fitting = 1 if project.dry_fitting else 0

    for d in doc.stone_details:
        # --- Validation: l2, b2, h2 must be less than 12 ---
        if (d.l2 or 0) >= 12:
            frappe.throw(_("L2 (inches) must be less than 12 in row {0}").format(d.idx))
        if (d.b2 or 0) >= 12:
            frappe.throw(_("B2 (inches) must be less than 12 in row {0}").format(d.idx))
        if (d.h2 or 0) >= 12:
            frappe.throw(_("H2 (inches) must be less than 12 in row {0}").format(d.idx))

        # --- Apply project checkboxes to child rows (always override) ---
        if project_chemical:
            d.chemical = 1
        if project_dry_fitting:
            d.dry_fitting = 1

        # --- Handle Range Expansion ---
        if d.range:
            numbers = []

            if "-" in d.range:
                try:
                    start, end = d.range.split("-")
                    start, end = int(start), int(end)
                except Exception:
                    frappe.throw(_("Invalid range format in row {0}. Use like 001-003").format(d.idx))

                if start > end:
                    frappe.throw(_("Range start cannot be greater than end in row {0}").format(d.idx))

                numbers = [i for i in range(start, end + 1)]

            elif "," in d.range:
                try:
                    numbers = [int(x.strip()) for x in d.range.split(",") if x.strip()]
                except Exception:
                    frappe.throw(_("Invalid list format in row {0}. Use like 001,002,005").format(d.idx))

            else:
                frappe.throw(_("Invalid range/list format in row {0}. Use like 001-003 or 001,002,005").format(d.idx))

            prefix = d.stone_code or (d.stone_name or "").upper()

            for i in numbers:
                new_row = {
                    "stone_name": d.stone_name,
                    "stone_code": f"{prefix}{i:03d}",
                    "l1": d.l1, "l2": d.l2,
                    "b1": d.b1, "b2": d.b2,
                    "h1": d.h1, "h2": d.h2,
                    "chemical": 1 if project_chemical else d.chemical,
                    "dry_fitting": 1 if project_dry_fitting else d.dry_fitting
                }

                # Calculate volume
                l = (new_row["l1"] or 0) + (new_row["l2"] or 0) / 12
                b = (new_row["b1"] or 0) + (new_row["b2"] or 0) / 12
                h = (new_row["h1"] or 0) + (new_row["h2"] or 0) / 12
                new_row["volume"] = round(l * b * h, 3)

                total += new_row["volume"]
                new_stone_details.append(new_row)

        else:
            # --- Normal row ---
            l = (d.l1 or 0) + (d.l2 or 0) / 12
            b = (d.b1 or 0) + (d.b2 or 0) / 12
            h = (d.h1 or 0) + (d.h2 or 0) / 12
            d.volume = round(l * b * h, 3)
            total += d.volume
            new_stone_details.append(d.as_dict())

    # --- Replace child table with expanded rows ---
    doc.stone_details = []
    for row in new_stone_details:
        doc.append("stone_details", row)

    doc.total_volume = round(total, 3)
