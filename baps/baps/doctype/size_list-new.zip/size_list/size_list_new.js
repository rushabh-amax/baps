// ============================
// Size List - Role-based Verification System
// ============================

// Add CSS for verification status styling
if (!document.querySelector('#verification-status-styles')) {
    const style = document.createElement('style');
    style.id = 'verification-status-styles';
    style.textContent = `
        /* Verified row styling */
        .grid-row.verification-verified {
            background-color: #d4edda !important;
            border-left: 5px solid #28a745 !important;
        }
        
        /* Partially verified row styling */
        .grid-row.verification-partial {
            background-color: #fff3cd !important;
            border-left: 5px solid #ffc107 !important;
        }
        
        /* Verified field styling */
        .verification-verified input,
        .verification-verified select,
        .verification-verified textarea {
            background-color: #d4edda !important;
            border: 1px solid #28a745 !important;
        }
        
        /* Verification checkbox styling */
        .verification-checkbox {
            accent-color: #28a745;
        }
        
        .verification-checkbox:checked {
            background-color: #28a745;
        }
        
        /* Hide verification fields for Data Operators */
        .hide-for-operator {
            display: none !important;
        }
    `;
    document.head.appendChild(style);
}

frappe.ui.form.on('Size List', {
    refresh: function(frm) {
        setup_role_based_permissions(frm);
        setup_verification_events(frm);
        update_verification_progress(frm);
        add_verification_buttons(frm);
        update_row_styling(frm);
    },
    
    // Main field verification events
    form_number_verified: function(frm) {
        handle_main_field_verification(frm, 'form_number', frm.doc.form_number_verified);
    },
    
    baps_project_verified: function(frm) {
        handle_main_field_verification(frm, 'baps_project', frm.doc.baps_project_verified);
    },
    
    prep_date_verified: function(frm) {
        handle_main_field_verification(frm, 'prep_date', frm.doc.prep_date_verified);
    },
    
    stone_type_verified: function(frm) {
        handle_main_field_verification(frm, 'stone_type', frm.doc.stone_type_verified);
    },
    
    main_part_verified: function(frm) {
        handle_main_field_verification(frm, 'main_part', frm.doc.main_part_verified);
    },
    
    sub_part_verified: function(frm) {
        handle_main_field_verification(frm, 'sub_part', frm.doc.sub_part_verified);
    },
    
    cutting_region_verified: function(frm) {
        handle_main_field_verification(frm, 'cutting_region', frm.doc.cutting_region_verified);
    },
    
    overall_form_verified: function(frm) {
        if (frm.doc.overall_form_verified) {
            mark_all_fields_verified(frm);
        }
    },
    
    // Field change events - reset verification when data changes
    form_number: function(frm) {
        if (frappe.user_roles.includes('Data Operator')) {
            frm.set_value('form_number_verified', 0);
            update_verification_progress(frm);
        }
    },
    
    baps_project: function(frm) {
        if (frappe.user_roles.includes('Data Operator')) {
            frm.set_value('baps_project_verified', 0);
            update_verification_progress(frm);
        }
    },
    
    prep_date: function(frm) {
        if (frappe.user_roles.includes('Data Operator')) {
            frm.set_value('prep_date_verified', 0);
            update_verification_progress(frm);
        }
    },
    
    stone_type: function(frm) {
        if (frappe.user_roles.includes('Data Operator')) {
            frm.set_value('stone_type_verified', 0);
            update_verification_progress(frm);
        }
    },
    
    main_part: function(frm) {
        if (frappe.user_roles.includes('Data Operator')) {
            frm.set_value('main_part_verified', 0);
            update_verification_progress(frm);
        }
    },
    
    sub_part: function(frm) {
        if (frappe.user_roles.includes('Data Operator')) {
            frm.set_value('sub_part_verified', 0);
            update_verification_progress(frm);
        }
    },
    
    cutting_region: function(frm) {
        if (frappe.user_roles.includes('Data Operator')) {
            frm.set_value('cutting_region_verified', 0);
            update_verification_progress(frm);
        }
    }
});

// Child table events
frappe.ui.form.on('Size List Details', {
    // Verification checkbox events
    stone_name_verified: function(frm, cdt, cdn) {
        handle_child_field_verification(frm, cdt, cdn, 'stone_name');
    },
    
    stone_code_verified: function(frm, cdt, cdn) {
        handle_child_field_verification(frm, cdt, cdn, 'stone_code');
    },
    
    l1_verified: function(frm, cdt, cdn) {
        handle_child_field_verification(frm, cdt, cdn, 'l1');
    },
    
    l2_verified: function(frm, cdt, cdn) {
        handle_child_field_verification(frm, cdt, cdn, 'l2');
    },
    
    b1_verified: function(frm, cdt, cdn) {
        handle_child_field_verification(frm, cdt, cdn, 'b1');
    },
    
    b2_verified: function(frm, cdt, cdn) {
        handle_child_field_verification(frm, cdt, cdn, 'b2');
    },
    
    h1_verified: function(frm, cdt, cdn) {
        handle_child_field_verification(frm, cdt, cdn, 'h1');
    },
    
    h2_verified: function(frm, cdt, cdn) {
        handle_child_field_verification(frm, cdt, cdn, 'h2');
    },
    
    row_verified: function(frm, cdt, cdn) {
        handle_row_verification(frm, cdt, cdn);
    },
    
    // Data field change events - reset verification
    stone_name: function(frm, cdt, cdn) {
        if (frappe.user_roles.includes('Data Operator')) {
            frappe.model.set_value(cdt, cdn, 'stone_name_verified', 0);
            update_child_row_verification(frm, cdt, cdn);
        }
        calculate_volume(frm, cdt, cdn);
    },
    
    stone_code: function(frm, cdt, cdn) {
        if (frappe.user_roles.includes('Data Operator')) {
            frappe.model.set_value(cdt, cdn, 'stone_code_verified', 0);
            update_child_row_verification(frm, cdt, cdn);
        }
    },
    
    l1: function(frm, cdt, cdn) {
        if (frappe.user_roles.includes('Data Operator')) {
            frappe.model.set_value(cdt, cdn, 'l1_verified', 0);
            update_child_row_verification(frm, cdt, cdn);
        }
        calculate_volume(frm, cdt, cdn);
    },
    
    l2: function(frm, cdt, cdn) {
        if (frappe.user_roles.includes('Data Operator')) {
            frappe.model.set_value(cdt, cdn, 'l2_verified', 0);
            update_child_row_verification(frm, cdt, cdn);
        }
        calculate_volume(frm, cdt, cdn);
    },
    
    b1: function(frm, cdt, cdn) {
        if (frappe.user_roles.includes('Data Operator')) {
            frappe.model.set_value(cdt, cdn, 'b1_verified', 0);
            update_child_row_verification(frm, cdt, cdn);
        }
        calculate_volume(frm, cdt, cdn);
    },
    
    b2: function(frm, cdt, cdn) {
        if (frappe.user_roles.includes('Data Operator')) {
            frappe.model.set_value(cdt, cdn, 'b2_verified', 0);
            update_child_row_verification(frm, cdt, cdn);
        }
        calculate_volume(frm, cdt, cdn);
    },
    
    h1: function(frm, cdt, cdn) {
        if (frappe.user_roles.includes('Data Operator')) {
            frappe.model.set_value(cdt, cdn, 'h1_verified', 0);
            update_child_row_verification(frm, cdt, cdn);
        }
        calculate_volume(frm, cdt, cdn);
    },
    
    h2: function(frm, cdt, cdn) {
        if (frappe.user_roles.includes('Data Operator')) {
            frappe.model.set_value(cdt, cdn, 'h2_verified', 0);
            update_child_row_verification(frm, cdt, cdn);
        }
        calculate_volume(frm, cdt, cdn);
    }
});

// Role-based permissions setup
function setup_role_based_permissions(frm) {
    const is_data_checker = frappe.user_roles.includes('Data Checker');
    const is_data_operator = frappe.user_roles.includes('Data Operator');
    
    if (is_data_checker && !is_data_operator) {
        // Data Checker: Read-only main fields, can check verification boxes
        make_data_fields_readonly(frm);
        show_verification_fields(frm);
    } else if (is_data_operator) {
        // Data Operator: Full editing rights on data fields
        make_data_fields_editable(frm);
        make_verification_fields_readonly(frm);
    }
}

function make_data_fields_readonly(frm) {
    const data_fields = [
        'form_number', 'baps_project', 'prep_date', 'stone_type', 
        'main_part', 'sub_part', 'cutting_region', 'polishing', 
        'chemical', 'dry_fitting', 'carving'
    ];
    
    data_fields.forEach(field => {
        frm.set_df_property(field, 'read_only', 1);
    });
}

function make_data_fields_editable(frm) {
    const data_fields = [
        'form_number', 'baps_project', 'prep_date', 'stone_type', 
        'main_part', 'sub_part', 'cutting_region', 'polishing', 
        'chemical', 'dry_fitting', 'carving'
    ];
    
    data_fields.forEach(field => {
        frm.set_df_property(field, 'read_only', 0);
    });
}

function make_verification_fields_readonly(frm) {
    const verification_fields = [
        'form_number_verified', 'baps_project_verified', 'prep_date_verified',
        'stone_type_verified', 'main_part_verified', 'sub_part_verified',
        'cutting_region_verified', 'overall_form_verified'
    ];
    
    verification_fields.forEach(field => {
        frm.set_df_property(field, 'read_only', 1);
    });
}

function show_verification_fields(frm) {
    const verification_fields = [
        'form_number_verified', 'baps_project_verified', 'prep_date_verified',
        'stone_type_verified', 'main_part_verified', 'sub_part_verified',
        'cutting_region_verified', 'overall_form_verified', 'verification_progress'
    ];
    
    verification_fields.forEach(field => {
        frm.set_df_property(field, 'hidden', 0);
    });
}

// Verification event handlers
function handle_main_field_verification(frm, field, is_verified) {
    if (is_verified) {
        frappe.show_alert({
            message: `✅ ${field} verified`,
            indicator: 'green'
        });
    } else {
        frappe.show_alert({
            message: `❌ ${field} verification removed`,
            indicator: 'orange'
        });
    }
    
    update_verification_progress(frm);
}

function handle_child_field_verification(frm, cdt, cdn, field) {
    const row = locals[cdt][cdn];
    const is_verified = row[field + '_verified'];
    
    if (is_verified) {
        frappe.show_alert({
            message: `✅ ${field} verified for ${row.stone_name || 'Row ' + row.idx}`,
            indicator: 'green'
        });
    } else {
        frappe.show_alert({
            message: `❌ ${field} verification removed for ${row.stone_name || 'Row ' + row.idx}`,
            indicator: 'orange'
        });
    }
    
    update_child_row_verification(frm, cdt, cdn);
    update_verification_progress(frm);
}

function handle_row_verification(frm, cdt, cdn) {
    const row = locals[cdt][cdn];
    
    if (row.row_verified) {
        // Mark all fields in this row as verified
        const verification_fields = [
            'stone_name_verified', 'stone_code_verified', 'l1_verified', 
            'l2_verified', 'b1_verified', 'b2_verified', 'h1_verified', 'h2_verified'
        ];
        
        verification_fields.forEach(field => {
            frappe.model.set_value(cdt, cdn, field, 1);
        });
        
        frappe.show_alert({
            message: `✅ Complete row verified for ${row.stone_name || 'Row ' + row.idx}`,
            indicator: 'green'
        });
    }
    
    update_child_row_verification(frm, cdt, cdn);
    update_verification_progress(frm);
}

// Progress calculation
function update_verification_progress(frm) {
    const main_verification_fields = [
        'form_number_verified', 'baps_project_verified', 'prep_date_verified',
        'stone_type_verified', 'main_part_verified', 'sub_part_verified',
        'cutting_region_verified'
    ];
    
    let verified_main_fields = 0;
    main_verification_fields.forEach(field => {
        if (frm.doc[field]) verified_main_fields++;
    });
    
    const main_progress = (verified_main_fields / main_verification_fields.length) * 100;
    
    // Calculate child table progress
    let total_child_fields = 0;
    let verified_child_fields = 0;
    
    frm.doc.stone_details.forEach(row => {
        const child_verification_fields = [
            'stone_name_verified', 'stone_code_verified', 'l1_verified',
            'l2_verified', 'b1_verified', 'b2_verified', 'h1_verified', 'h2_verified'
        ];
        
        child_verification_fields.forEach(field => {
            total_child_fields++;
            if (row[field]) verified_child_fields++;
        });
    });
    
    const child_progress = total_child_fields > 0 ? (verified_child_fields / total_child_fields) * 100 : 100;
    
    // Overall progress
    const overall_progress = (main_progress + child_progress) / 2;
    
    frm.set_value('verification_progress', Math.round(overall_progress));
    
    // Update overall form verified if everything is verified
    if (overall_progress === 100) {
        frm.set_value('overall_form_verified', 1);
    } else {
        frm.set_value('overall_form_verified', 0);
    }
}

function update_child_row_verification(frm, cdt, cdn) {
    const row = locals[cdt][cdn];
    const verification_fields = [
        'stone_name_verified', 'stone_code_verified', 'l1_verified',
        'l2_verified', 'b1_verified', 'b2_verified', 'h1_verified', 'h2_verified'
    ];
    
    let verified_count = 0;
    verification_fields.forEach(field => {
        if (row[field]) verified_count++;
    });
    
    // Auto-check row_verified if all fields are verified
    if (verified_count === verification_fields.length) {
        frappe.model.set_value(cdt, cdn, 'row_verified', 1);
    } else {
        frappe.model.set_value(cdt, cdn, 'row_verified', 0);
    }
    
    update_row_styling(frm);
}

// Visual styling updates
function update_row_styling(frm) {
    setTimeout(() => {
        frm.doc.stone_details.forEach((row, index) => {
            const verification_fields = [
                'stone_name_verified', 'stone_code_verified', 'l1_verified',
                'l2_verified', 'b1_verified', 'b2_verified', 'h1_verified', 'h2_verified'
            ];
            
            let verified_count = 0;
            verification_fields.forEach(field => {
                if (row[field]) verified_count++;
            });
            
            const grid_row = frm.fields_dict.stone_details.grid.grid_rows[index];
            if (grid_row && grid_row.wrapper) {
                grid_row.wrapper.classList.remove('verification-verified', 'verification-partial');
                
                if (verified_count === verification_fields.length) {
                    grid_row.wrapper.classList.add('verification-verified');
                } else if (verified_count > 0) {
                    grid_row.wrapper.classList.add('verification-partial');
                }
            }
        });
    }, 100);
}

// Utility functions
function add_verification_buttons(frm) {
    if (frappe.user_roles.includes('Data Checker') && !frappe.user_roles.includes('Data Operator')) {
        frm.add_custom_button(__('Mark All Verified'), function() {
            mark_all_fields_verified(frm);
        }, __('Verification'));
        
        frm.add_custom_button(__('Reset Verification'), function() {
            reset_all_verification(frm);
        }, __('Verification'));
    }
}

function mark_all_fields_verified(frm) {
    frappe.confirm(__('Mark all fields as verified?'), () => {
        // Mark main fields
        const main_verification_fields = [
            'form_number_verified', 'baps_project_verified', 'prep_date_verified',
            'stone_type_verified', 'main_part_verified', 'sub_part_verified',
            'cutting_region_verified'
        ];
        
        main_verification_fields.forEach(field => {
            frm.set_value(field, 1);
        });
        
        // Mark child fields
        frm.doc.stone_details.forEach((row, index) => {
            const child_verification_fields = [
                'stone_name_verified', 'stone_code_verified', 'l1_verified',
                'l2_verified', 'b1_verified', 'b2_verified', 'h1_verified', 'h2_verified', 'row_verified'
            ];
            
            child_verification_fields.forEach(field => {
                frappe.model.set_value('Size List Details', row.name, field, 1);
            });
        });
        
        update_verification_progress(frm);
        update_row_styling(frm);
        
        frappe.show_alert({
            message: __('All fields marked as verified'),
            indicator: 'green'
        });
    });
}

function reset_all_verification(frm) {
    frappe.confirm(__('Reset all verification states?'), () => {
        // Reset main fields
        const main_verification_fields = [
            'form_number_verified', 'baps_project_verified', 'prep_date_verified',
            'stone_type_verified', 'main_part_verified', 'sub_part_verified',
            'cutting_region_verified', 'overall_form_verified'
        ];
        
        main_verification_fields.forEach(field => {
            frm.set_value(field, 0);
        });
        
        // Reset child fields
        frm.doc.stone_details.forEach((row, index) => {
            const child_verification_fields = [
                'stone_name_verified', 'stone_code_verified', 'l1_verified',
                'l2_verified', 'b1_verified', 'b2_verified', 'h1_verified', 'h2_verified', 'row_verified'
            ];
            
            child_verification_fields.forEach(field => {
                frappe.model.set_value('Size List Details', row.name, field, 0);
            });
        });
        
        update_verification_progress(frm);
        update_row_styling(frm);
        
        frappe.show_alert({
            message: __('All verification states reset'),
            indicator: 'orange'
        });
    });
}

function calculate_volume(frm, cdt, cdn) {
    let row = locals[cdt][cdn];
    if (row) {
        let l = (row.l1 || 0) + (row.l2 || 0) / 12;
        let b = (row.b1 || 0) + (row.b2 || 0) / 12;
        let h = (row.h1 || 0) + (row.h2 || 0) / 12;
        
        row.volume = Math.round(l * b * h * 1000) / 1000;
        frm.refresh_field('stone_details');
    }
}

function setup_verification_events(frm) {
    // This function can be used for any additional verification setup
    // Currently handled by individual field events
}
