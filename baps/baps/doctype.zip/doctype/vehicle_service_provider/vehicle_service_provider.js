// Copyright (c) 2025, Amax Consultancy Pvt Ltd and contributors
// For license information, please see license.txt

// frappe.ui.form.on("Vehicle Service Provider", {
// 	refresh(frm) {

// 	},
// });
