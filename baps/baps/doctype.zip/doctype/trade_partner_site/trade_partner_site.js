// Copyright (c) 2025, Dharmesh Rathod and contributors
// For license information, please see license.txt

// frappe.ui.form.on("Trade Partner Site", {
// 	refresh(frm) {

// 	},
// });
