# Copyright (c) 2025, kavin and contributors
# For license information, please see license.txt

# import frappe
from frappe.model.document import Document


class StoneType(Document):
	pass
