# Copyright (c) 2025, Amax Consultancy Pvt Ltd and Contributors
# See license.txt

# import frappe
from frappe.tests.utils import FrappeTestCase


class TestTransportSiteAllocation(FrappeTestCase):
	pass
