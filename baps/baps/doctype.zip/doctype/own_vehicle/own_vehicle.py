# Copyright (c) 2025, Amax Consultancy Pvt Ltd and contributors
# For license information, please see license.txt

# import frappe
from frappe.model.document import Document


class OwnVehicle(Document):
	pass
